#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 25 23:30:46 2020

@author: sindy
"""
import json

def save_file(books, filename):
    with open(filename, "w") as file:
        json.dump(books, file)  
        
def read_file(filename):
    global books
    with open(filename, "r") as file:
        books = json.load(file)    
        return books
