"""
Concerned with storing and retrieving books from a list.
"""

import json

filename = "books_database.txt"

books = []      
new_list = []

def add_book(name, author):
    books.append({'name': name, 'author': author, 'read': False})
    save_file(books, filename)
#    Since it is only storing go do not need any return books
def save_file(books, filename):
    with open(filename, "w") as file:
        json.dump(books, file)  
 
def read_file(filename):
    global books
    with open(filename, "r") as file:
        books = json.load(file)    
        return books
    
def get_list_book():
    # global books
    read_file(filename)    
    # with open(filename, "r") as file:
    #     books = json.load(file)       
    for book in books: 
        print(f"Title:{book['name']}\t Author:{book['author']}\t Status:{book['read']}\n")
                  
def mark_as_read(mark_book):
    read_file(filename)    
    # with open(filename, "r") as file:
    #     file_content = json.load(file)           
        # key_name = "name"
    # read_book = input('What is the book you have read? ')
    for book in books:
        if book['name']== mark_book:
            book['read'] = True
    save_file(books, filename)
# with open(filename, "w") as file:
#     json.dump(file_content, file) 


##    
#def save():
#    with open(filename, "w") as file:
#        json.dump(file_content, file) 
        
def delete_book(delete_this_book):
    read_file(filename)    
    # with open(filename, "r") as file:
    #     file_content = json.load(file)  
    for book in books:
        if book['name'] != delete_this_book:
            new_list.append(book)                
    with open(filename, "w") as file:
        json.dump(new_list, file) 
#    


        

        