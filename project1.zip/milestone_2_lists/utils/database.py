"""
Concerned with storing and retrieving books from a list.
"""

import json

filename = "books_database.txt"

books = []      
new_list = []

def add_book(name, author):
    books.append({'name': name, 'author': author, 'read': False})
    save_file(books, filename)
#    Since it is only storing go do not need any return books
def save_file(books, filename):
    with open(filename, "w") as file:
        json.dump(books, file)  
        
def read_file(filename):
    global books
    with open(filename, "r") as file:
        books = json.load(file)    
        return books
    
def get_list_book():
    read_file(filename)         
    for book in books: 
        print(f"Title:{book['name']}\t Author:{book['author']}\t Status:{book['read']}\n")
                  
def mark_as_read(mark_book):
    read_file(filename)    
    for book in books:
        if book['name']== mark_book:
            book['read'] = True
    save_file(books, filename)

def delete_book(delete_this_book):
    read_file(filename)    
    for book in books:
        if book['name'] != delete_this_book:
            new_list.append(book)                
    with open(filename, "w") as file:
        json.dump(new_list, file) 
#    


        

        